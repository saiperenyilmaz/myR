require("IBrokers");require("stringr");require("httr");require("data.table");require("lubridate");require("quantmod");require("tidyr")
require("websocket")

# json to Login
headers = list(
  `Host` = "streaming.forexpros.com",
  `command` = "LOGIN",
  `Connection` = 'Upgrade',
  `Pragma` = 'no-cache',
  `Cache-Control` = 'no-cache',
  `User-Agent` = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
  `Upgrade` = 'websocket',
  `Origin` =  'https://econcal.forexprostools.com',
  `Sec-WebSocket-Version` =  '13',
  `Accept-Encoding` = 'gzip, deflate, br',
  `Accept-Language` = 'en-US,en;q=0.9',
  `Sec-WebSocket-Key` =  '5JSK3alLoGhR5rIiWReEWA==',
  `Sec-WebSocket-Extensions` = 'permessage-deflate; client_max_window_bits'
)


msg1 = toJSON('{"_event":"bulk-subscribe","message":"event-480887:%%event-481892:%%event-480886:%%event-480930:%%event-480929:%%event-480941:%%event-480940:%%event-480944:%%event-480939:%%event-480943:%%event-480946:%%event-481895:%%event-480955:%%event-480959:%%event-480960:%%event-481764:%%event-480963:%%event-481998:%%event-482002:%%event-481999:%%event-482001:%%event-482003:%%event-480967:%%event-480970:%%event-480965:%%event-480966:%%event-480964:%%event-481762:%%event-480968:%%event-480969:%%event-481763:%%event-480195:%%event-480983:%%event-480980:%%event-480977:%%event-480978:%%event-480981:%%event-480979:%%event-481725:%%event-481723:%%event-481724:%%event-480987:%%event-480988:%%event-480986:%%event-482006:%%event-480989:%%event-480990:%%event-480711:%%event-480712:%%event-481726:%%event-481958:%%event-481953:%%event-481954:%%event-481957:%%event-481949:%%event-481952:%%event-481950:%%event-481955:%%event-481956:%%event-481951:%%event-481728:%%event-481727:%%event-482007:%%event-481834:%%event-481755:%%event-481835:%%event-481896:%%event-481897:%%event-481906:%%event-481568:%%event-482008:%%event-481005:%%event-481004:%%event-481007:%%event-481013:%%event-481014:%%event-481008:%%event-481011:%%event-481009:%%event-481006:%%event-481012:%%event-481010:"}',auto_unbox = F,pretty = T)
msg2 = toJSON('{"_event":"UID","UID":0}',auto_unbox = F,pretty = T)
msg3 = toJSON('{"_event":"heartbeat","data":"h"}',auto_unbox = F,pretty = T)


# socket url/connection
mySock = websocket::WebSocket$new(paste0("wss://streaming.forexpros.com/echo/552/f1_0rl9m/websocket"),
                                  headers = toJSON(headers,pretty = TRUE,auto_unbox = TRUE),autoConnect = TRUE
                                  )

#mySock$connect()
#cat("\nBuilding onMessage")
mySock$onMessage(function(evt){
  # assign data to folder
  saveRDS(evt$data, paste0(gsub("\\.","",gsub(" ","",
                                              paste0("~/Desktop/macro/",
                                                     gsub(":","-",format(Sys.time(),
                                                                         format='%Y-%m-%d %H:%M:%S.%OS6'))))),".rds"))
  return(evt$data)
})

mySock$onOpen(function(evt){
  mySock$send(msg1)
  mySock$send(msg2)
})
# ****************************************************************************************************************
# ****************************************************************************************************************
# while(STATUS != 1){cat(".");STATUS<-mySock$readyState()[1];Sys.sleep(1)}
for(ii in 1:5){
  Sys.sleep(1)
  STATUS <- mySock$readyState()[1]
  later::run_now()
  if(STATUS == 1){break}
  cat(ii)
}
print(mySock$readyState()[1])
# get CHART_HISTORY_SPY
#cat("\nNow sending json blocks...")
while(TRUE){
  mySock$send(msg3)
  Sys.sleep(1)
  later::run_now()
 cat("\nHeartbeat")
}

# logout of streamer / close connection
#cat("\nNow closing Streamer")
#mySock$close() 

getStreamData = function(){

# read in messages and detect those with actual data
txt <- do.call(rbind,lapply(as.list(list.files("~/Desktop/macro",full.names = TRUE)), readRDS))
txt = txt[!str_detect(string = txt,pattern = "heartbeat"),]
txt = txt[str_length(string = txt)>1]
# remove backslashes
txt = gsub("\\\\",'',txt)
txt = gsub('\\"','',txt)
# remove opening/closing bracket
txt2 <- gsub('\\[','',txt)
txt2 <- gsub("\\]",'',txt2)
# remove opening braces
txt2 <- str_split(txt2,"\\{")
# extract last obs in list
txt2 <- txt2[[1]][length(txt2[[1]])]
# remove closing brace
txt2 <- gsub("\\}",'',txt2)
# removes comma between digits only
txt2 = str_replace_all(txt2,"([0-9]),([0-9])", "\\1\\2")
# split by commas
txt2 <- str_split(txt2,pattern = ",")[[1]]
# convert to data frame by splitting by colons
df <- as.data.frame(t(do.call(rbind,str_split(txt2,pattern = ":"))))
# re-assign column names (from the first row)
colnames(df) = df[1,]
# drop the first row
df = df[-1,]
# convert previous, forecast, actual to numeric
df
}

View(getStreamData())
